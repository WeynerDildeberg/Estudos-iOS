//: A UIKit based Playground for presenting user interface

import UIKit


extension UIButton {
    func makeCircular (){
        self.clipsToBounds = true
        self.layer.cornerRadius = self.frame.size.width / 2
    }
}

let button = UIButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
button.backgroundColor = .red

button.makeCircular()



extension Double {
    func round(to places: Int) -> Double {
        let precissionNumber = pow(10, Double(places))
        var n = self
        n = n * precissionNumber
        n.round()
        n = n / precissionNumber
        return n
    }
}

var myDouble: Double = 3.14599
myDouble.round(to: 3)


